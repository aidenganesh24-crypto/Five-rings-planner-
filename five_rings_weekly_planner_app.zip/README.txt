THE FIVE RINGS WEEKLY PLANNER

Quick use:
- Open index.html in a modern browser to use the planner.
- Checkmarks are saved in that browser on that device.

To install it as a true Android home-screen app (PWA):
1. Put index.html, manifest.json, and sw.js on a secure HTTPS host.
2. Open the hosted page in Chrome on Android.
3. Use Chrome's menu (three dots) and choose "Install app" or "Add to Home screen" if offered.

The ZIP is a small web app bundle, not an Android APK.